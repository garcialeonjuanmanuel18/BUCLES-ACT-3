const palab=[abeja, Gato, chimuelo, langostino];
console.log(palab);

palab.splice(0,1);
palab.splice(2,1);

for(let i=0; i<palab.length;i++){
    let minusculas=palab[i].tolowercase();
    
}

console.log()


const palab=['hola', 'adios', 'buenas', 'andaluz'];

for(let i=0; i<palab.length;i++){
    if(palabra)
}
